# print("Python has three numeric types: int, float, and complex")
# myvalue=1
# print(myvalue)
# print(type(myvalue))
# print(str(myvalue) + "is of datatype" +str(type(myvalue)))

# myvalue=3.14
# print(myvalue)
# print(str(myvalue) + "is of datatype" +str(type(myvalue)))
# myvalue=5j
# print(myvalue)
# print(type(myvalue))
# print(str(myvalue) + "is of datatype" +str(type(myvalue)))
# x=True
# print(x)
# print(type(x))
# print(str(x) + "is type of" +str(type(x)))

# mystring=("This is a string")
# print(type(mystring))
# print(mystring + "is type of" +str(type(mystring)))
# firststring="water"
# secondstring="fall"
# thirdstring=firststring+secondstring
# print(thirdstring)
# name=input("what is your name?")
# print(name)
# color=input("what is your fav color?")
# animal=input("what is ur fav animal?")
# print("{},you like a {} {}!".format(name,color,animal))
# myfruitlist=["apple","cherry","banana"]
# print(myfruitlist)
# print(type(myfruitlist))
# print(myfruitlist[1])
# myfruitlist[2]="peaches"
# print(myfruitlist)
# myFinalAnswerTuple = ("apple", "banana", "pineapple")
# print(myFinalAnswerTuple)
# print(type(myFinalAnswerTuple))
# print(myFinalAnswerTuple[0])
# print(myFinalAnswerTuple[1])
# print(myFinalAnswerTuple[2])

# myFavoriteFruitDictionary = {
#   "Akua" : "apple",
#   "Saanvi" : "banana",
#   "Paulo" : "pineapple"
# }
# print(myFavoriteFruitDictionary)
# print(type(myFavoriteFruitDictionary))
# print(myFavoriteFruitDictionary["Akua"])
# print(myFavoriteFruitDictionary["Saanvi"])
# print(myFavoriteFruitDictionary["Paulo"])
# myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
# for item in myMixedTypeList:
#     print("{} is of the data type {}".format(item,type(item)))
# userReply = input("Do you need to ship a package? (Enter yes or no) ")
# if userReply == "yes":
#     print("We can help you ship that package!")
# else:
#     print("Please come back when you need to ship a package. Thank you.")
# userReply = input("Would you like to buy stamps, buy an envelope, or make a copy?")
# if userReply == "stamps":
#     print("We have many stamp designs to choose from.")
# elif userReply == "envelope":
#     print("We have many envelope sizes to choose from.")
# elif userReply == "copy":
#     copies = input("How many copies would you like? (Enter a number) ")
#     print("Here are {} copies.".format(copies))
# else:
#     print("Thank you, please come again.")
print("Welcome to Guess the Number!")
print("The rules are simple. I will think of a number, and you will try to guess it.")
import random
number=random.randint(1,10)
isGuessRight=False
while isGuessRight != True:
    guess = input("Guess a number between 1 and 10: ")
    if int(guess) == number:
        print("You guessed {}. That is correct! You win!".format(guess))
        isGuessRight = True
    else:
        print("You guessed {}. Sorry, that isn’t it. Try again.".format(guess))